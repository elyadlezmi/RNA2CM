#!/usr/bin/bash

##data setup script 

#################################################################################
# these lines should be modified according to your system and sample
THREADS=10
READ_LENGTH=101
#################################################################################

# step 9
mkdir ~/RNA2CM/data/GRCh38
cd ~/RNA2CM/data/GRCh38
STAR --runThreadN $THREADS --runMode genomeGenerate --genomeDir ~/RNA2CM/data/GRCh38 --genomeFastaFiles ~/RNA2CM/data/GRCh38.primary_assembly.genome.fa --sjdbGTFfile ~/RNA2CM/data/gencode.v34.primary_assembly.annotation.gtf --sjdbOverhang $(($READ_LENGTH-1)) 
cd ..

mkdir ~/RNA2CM/data/GRCm38
cd ~/RNA2CM/data/GRCm38
STAR --runThreadN $THREADS --runMode genomeGenerate --genomeDir ~/RNA2CM/data/GRCm38 --genomeFastaFiles ~/RNA2CM/data/GRCm38.primary_assembly.genome.fa --sjdbGTFfile ~/RNA2CM/data/gencode.vM25.primary_assembly.annotation.gtf --sjdbOverhang $(($READ_LENGTH-1))

# step 10
cd ~/RNA2CM/data
samtools faidx GRCh38.primary_assembly.genome.fa
~/RNA2CM/bin/gatk-4.1.8.0/gatk CreateSequenceDictionary -R GRCh38.primary_assembly.genome.fa

# step 11
awk '{if($3=="exon") {print $1"\t"$4-100"\t"$5+100"\t"substr($16,2,length($16)-3)}}' gencode.v34.primary_assembly.annotation.gtf | sort -k 1,1 -k2,2n | bgzip > GRCh38_exome.bed.gz
tabix GRCh38_exome.bed.gz

# step 12 
# rename chromosomes of dbSNP file
bcftools annotate --threads $THREADS --output-type z --rename-chrs remapNCBI.txt --output dbSNPbuild154Renamed.vcf.gz GCF_000001405.38.gz
tabix dbSNPbuild154Renamed.vcf.gz


# rename chromosomes of COSMIC file
tabix CosmicCodingMuts.vcf.gz
bcftools annotate --threads $THREADS --output-type z --rename-chrs remapCOSMIC.txt --output CosmicCodingMutsRenamed.vcf.gz CosmicCodingMuts.vcf.gz
tabix CosmicCodingMutsRenamed.vcf.gz


# test setup success
success=true

for file in dbSNPbuild154Renamed.vcf.gz dbSNPbuild154Renamed.vcf.gz.tbi GRCm38.primary_assembly.genome.fa CosmicCodingMutsRenamed.vcf.gz CosmicCodingMutsRenamed.vcf.gz.tbi ~/RNA2CM/data/GRCh38/Genome ~/RNA2CM/data/GRCm38/Genome GRCh38_exome.bed.gz GRCh38_exome.bed.gz.tbi GRCh38.primary_assembly.genome.fa.fai GRCh38.primary_assembly.genome.dict;

do
if ! test -f $file; then
	echo $file "was not generated!!" 
	success=false
fi
done

if [ $success = true ]; then
	rm GCF_000001405.38.gz GCF_000001405.38.gz.tbi CosmicCodingMuts.vcf.gz CosmicCodingMuts.vcf.gz.tbi
	echo "All files were successfully generated.
You can proceed to the analysis."

else 
	echo "The process failed"
fi
