
import pandas as pd
import sys

SAMPLE = sys.argv[1]

COSMIC_CENSUS = '~/RNA2CM/data/CosmicMutantExportCensus.tsv.gz'

mutations = pd.read_csv(f'{COSMIC_CENSUS}', sep='\t', compression='gzip')
mutations = mutations[mutations['Mutation Description'] != 'Substitution - coding silent']
mutations = mutations[mutations['FATHMM prediction'] == 'PATHOGENIC']
mutations = mutations[mutations['Tier'] == 1]
mutations = mutations[['Gene name','GENOMIC_MUTATION_ID', 'Mutation AA', 'Mutation Description', 'FATHMM score']]

df = pd.read_csv(SAMPLE+'final.tsv', sep='\t')
df = df.merge(mutations, left_on='[5]ID', right_on='GENOMIC_MUTATION_ID')
df['[7]CNT'] = df['[7]CNT'].astype("int32")
df = df[df['[9]COMMON'] != '1']
df = df[df['[7]CNT'] >= 10]
df.drop_duplicates(subset='[5]ID', inplace=True)

df = df[['# [1]CHROM', '[2]POS', '[3]REF', '[4]ALT', 'Gene name', '[6]QUAL', '[7]CNT', '[8]RS', '[11]ES:AD', 'GENOMIC_MUTATION_ID', 'Mutation AA', 'Mutation Description', 'FATHMM score']]
df.rename({'CHROM', 'POS', 'REF', 'ALT', 'QUAL', 'CNT', 'RS(dbSNP)', 'AD'})


df.to_csv(f'{SAMPLE}_cancer_mutations.csv')
