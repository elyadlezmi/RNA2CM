#!/usr/bin/bash

## step 4

cd ~/RNA2CM/bin

wget http://www.usadellab.org/cms/uploads/supplementary/Trimmomatic/Trimmomatic-0.39.zip
wget https://github.com/broadinstitute/gatk/releases/download/4.1.8.0/gatk-4.1.8.0.zip

unzip Trimmomatic-0.39.zip
unzip gatk-4.1.8.0.zip

## step 5
cd ~/RNA2CM/data

wget ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_34/GRCh38.primary_assembly.genome.fa.gz
wget ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_34/gencode.v34.primary_assembly.annotation.gtf.gz

wget ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_mouse/release_M25/GRCm38.primary_assembly.genome.fa.gz
wget ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_mouse/release_M25/gencode.vM25.primary_assembly.annotation.gtf.gz

gunzip GRCh38.primary_assembly.genome.fa.gz gencode.v34.primary_assembly.annotation.gtf.gz GRCm38.primary_assembly.genome.fa.gz gencode.vM25.primary_assembly.annotation.gtf.gz

## step 6
wget https://ftp.ncbi.nih.gov/snp/latest_release/VCF/GCF_000001405.38.gz
wget https://ftp.ncbi.nih.gov/snp/latest_release/VCF/GCF_000001405.38.gz.tbi


### these line test successfulle download of the files ##########
success=true

for file in GRCh38.primary_assembly.genome.fa gencode.v34.primary_assembly.annotation.gtf GRCm38.primary_assembly.genome.fa gencode.vM25.primary_assembly.annotation.gtf GCF_000001405.38.gz GCF_000001405.38.gz.tbi CosmicMutantExportCensus.tsv.gz CosmicCodingMuts.vcf.gz ~/RNA2CM/bin/Trimmomatic-0.39/trimmomatic-0.39.jar ~/RNA2CM/bin/gatk-4.1.8.0/gatk;

do
if ! test -f $file; then
	echo $file "is missing. download it manually or correct the url link." 
	success=false
fi
done


if [ $success = true ]; then
	rm ~/RNA2CM/bin/Trimmomatic-0.39.zip ~/RNA2CM/bin/gatk-4.1.8.0.zip
	echo "All files were sccessfully downloaded.
You can proceed to the reference data setup stage (step 9)."

else 
	echo "The process failed"
fi
