#!/usr/bin/bash 

# pipeline for identification of cancer related mutations

#################################################################################
# these lines should be modified according to your system and sample
THREADS=10  # number of processors for multi-threading
JAVA_RAM=64  # how much RAM to allocate for Java processes (in GB)
DELETE_INTERMEDIATES=true  # do you want to delete intermediate files (True/False)
FILTER_MOUSE_READS=true # do you want to apply filtering of mouse reads (True/False)
#################################################################################


SAMPLE=$1  #  name of the sample (name without "fastq.gz" extension)
LIBRARY_LAYOUT=$2  # paired / single

# absolute path to Java programs
TRIMMOMATIC=~/RNA2CM/bin/Trimmomatic-0.39/trimmomatic-0.39.jar
GATK=~/RNA2CM/bin/gatk-4.1.8.0/gatk
# absolute path to annotations and reference files
STAR_HUMAN_INDEX=~/RNA2CM/data/GRCh38
STAR_MOUSE_INDEX=~/RNA2CM/data/GRCm38
REFERENCE_GENOME=~/RNA2CM/data/GRCh38.primary_assembly.genome.fa
INTERVALS=~/RNA2CM/data/GRCh38_exome.bed.gz
DBSNP=~/RNA2CM/data/dbSNPbuild154Renamed.vcf.gz
COSMIC_VCF=~/RNA2CM/data/CosmicCodingMutsRenamed.vcf.gz
HEADER=~/RNA2CM/data/header.txt


### Read trimming and alignment to the reference genome ###
if [ $LIBRARY_LAYOUT = single ]; then  # single end
# trimmomatic
    ADAPTER_LIST=~/RNA2CM/bin/Trimmomatic-0.39/adapters/TruSeq3-SE.fa
    java -Xmx${JAVA_RAM}g -jar $TRIMMOMATIC SE -threads $THREADS ${SAMPLE}.fastq.gz ${SAMPLE}.trimmed.fastq.gz ILLUMINACLIP:$ADAPTER_LIST:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36
# alignment to human genome
    STAR --runThreadN $THREADS --genomeDir $STAR_HUMAN_INDEX --readFilesIn ${SAMPLE}.trimmed.fastq.gz --outFileNamePrefix ${SAMPLE} --outSAMtype BAM SortedByCoordinate --readFilesCommand zcat --outSAMattributes NM --twopassMode Basic
    if $FILTER_MOUSE_READS; then
# alignment to mouse genome
        STAR --runThreadN $THREADS --genomeDir $STAR_MOUSE_INDEX --readFilesIn ${SAMPLE}.trimmed.fastq.gz --outFileNamePrefix ${SAMPLE}GRCm --outSAMtype BAM SortedByCoordinate --readFilesCommand zcat --outSAMattributes NM --twopassMode Basic
    fi

elif [ $LIBRARY_LAYOUT = paired ]; then # paired end
# trimmomatic
    ADAPTER_LIST=~/RNA2CM/bin/Trimmomatic-0.39/adapters/TruSeq3-PE.fa
    java -Xmx${JAVA_RAM}g -jar $TRIMMOMATIC PE -threads $THREADS ${SAMPLE}_1.fastq.gz ${SAMPLE}_2.fastq.gz ${SAMPLE}_1_paired.fastq.gz ${SAMPLE}_1_unpaired.fastq.gz ${SAMPLE}_2_paired.fastq.gz ${SAMPLE}_2_unpaired.fastq.gz ILLUMINACLIP:$ADAPTER_LIST:2:30:10:2:keepBothReads LEADING:3 TRAILING:3 MINLEN:36
# alignment to human genome
    STAR --runThreadN $THREADS --genomeDir $STAR_HUMAN_INDEX --readFilesIn ${SAMPLE}_1_paired.fastq.gz ${SAMPLE}_2_paired.fastq.gz --outFileNamePrefix ${SAMPLE} --outSAMtype BAM SortedByCoordinate --readFilesCommand zcat --outSAMattributes NM --twopassMode Basic
# alignment to mouse genome
    if $FILTER_MOUSE_READS; then
        STAR --runThreadN $THREADS --genomeDir $STAR_MOUSE_INDEX --readFilesIn ${SAMPLE}_1_paired.fastq.gz ${SAMPLE}_2_paired.fastq.gz --outFileNamePrefix ${SAMPLE}GRCm --outSAMtype BAM SortedByCoordinate --readFilesCommand zcat --outSAMattributes NM --twopassMode Basic
    fi
fi


if $DELETE_INTERMEDIATES; then
    rm -rf ${SAMPLE}_1_paired.fastq.gz ${SAMPLE}_2_paired.fastq.gz ${SAMPLE}_1_unpaired.fastq.gz ${SAMPLE}_2_unpaired.fastq.gz ${SAMPLE}Log.out ${SAMPLE}SJ.out.tab ${SAMPLE}Log.progress.out ${SAMPLE}GRCmLog.out ${SAMPLE}GRCmSJ.out.tab ${SAMPLE}GRCmLog.progress.out ${SAMPLE}Log.out ${SAMPLE}GRCm_STARtmp ${SAMPLE}_STARtmp ${SAMPLE}.trimmed.fastq.gz ${SAMPLE}GRCm_STARgenome ${SAMPLE}GRCm_STARpass1 ${SAMPLE}_STARgenome ${SAMPLE}_STARpass1
fi

### filter our reads of murine origin ###

if $FILTER_MOUSE_READS; then

    cat << EOF > xeno.R # write the R script
    #!/usr/bin/R
    library("XenofilteR")
    bp.param <- SnowParam(workers = $THREADS, type = "SOCK")
    sample.list <- matrix(c('${SAMPLE}Aligned.sortedByCoord.out.bam','${SAMPLE}GRCmAligned.sortedByCoord.out.bam'),ncol=2)
    output.names <- c('${SAMPLE}')
    XenofilteR(sample.list, destination.folder = "./", MM_threshold = 8, bp.param = bp.param, output.names)
EOF

    Rscript xeno.R # excecute R script
fi 

### GATK best practice for variant calling from RNA-seq ###

# mark duplicates
if $FILTER_MOUSE_READS; then
    $GATK --java-options "-Xmx${JAVA_RAM}g" MarkDuplicates --CREATE_INDEX true --I ./Filtered_bams/${SAMPLE}_Filtered.bam --O ${SAMPLE}marked_duplicates.bam --VALIDATION_STRINGENCY SILENT --M ${SAMPLE}marked_dup_metrics.txt
else
    $GATK --java-options "-Xmx${JAVA_RAM}g" MarkDuplicates --CREATE_INDEX true --I ${SAMPLE}Aligned.sortedByCoord.out.bam --O ${SAMPLE}marked_duplicates.bam --VALIDATION_STRINGENCY SILENT --M ${SAMPLE}marked_dup_metrics.txt
fi
# split N
$GATK --java-options "-Xmx${JAVA_RAM}g" SplitNCigarReads -L $INTERVALS -R $REFERENCE_GENOME -I ${SAMPLE}marked_duplicates.bam -O ${SAMPLE}splitN.bam
# add read groups
$GATK --java-options "-Xmx${JAVA_RAM}g" AddOrReplaceReadGroups --CREATE_INDEX true --I ${SAMPLE}splitN.bam --O ${SAMPLE}.grouped.bam --RGID rnasq --RGLB lb --RGPL illumina --RGPU pu --RGSM ES
# base recalibration
$GATK --java-options "-Xmx${JAVA_RAM}g" BaseRecalibrator -L $INTERVALS -I ${SAMPLE}.grouped.bam --use-original-qualities -R $REFERENCE_GENOME --known-sites $DBSNP -O ${SAMPLE}.recal_data.table
# apply base recalibration
$GATK --java-options "-Xmx${JAVA_RAM}g" ApplyBQSR -L $INTERVALS -R $REFERENCE_GENOME -I ${SAMPLE}.grouped.bam --use-original-qualities --add-output-sam-program-record --bqsr-recal-file ${SAMPLE}.recal_data.table -O ${SAMPLE}.recal_output.bam
# variant calling
$GATK --java-options "-Xmx${JAVA_RAM}g" HaplotypeCaller -L $INTERVALS -R $REFERENCE_GENOME -I ${SAMPLE}.recal_output.bam -O ${SAMPLE}.output.vcf.gz --dont-use-soft-clipped-bases --pcr-indel-model AGGRESSIVE

if $DELETE_INTERMEDIATES; then
    rm -rf ${SAMPLE}marked_duplicates.bam ${SAMPLE}marked_duplicates.bai ${SAMPLE}marked_duplicates.bai ${SAMPLE}marked_dup_metrics.txt rm -rf ${SAMPLE}splitN.bam ${SAMPLE}splitN.bai ${SAMPLE}.grouped.bam ${SAMPLE}.grouped.bam.bai ${SAMPLE}.grouped.bai ${SAMPLE}.recal_data.table ${SAMPLE}.recal_output.bam ${SAMPLE}.recal_output.bai ${SAMPLE}GRCmAligned.sortedByCoord.out.bam ${SAMPLE}GRCmAligned.sortedByCoord.out.bam.bai ${SAMPLE}Aligned.sortedByCoord.out.bam ${SAMPLE}Aligned.sortedByCoord.out.bam.bai ${SAMPLE}GRCmLog.final.out ${SAMPLE}Log.final.out xeno.R
fi

### Hard filtering of VCF ###
# variant filtration
$GATK --java-options "-Xmx${JAVA_RAM}g" VariantFiltration --R $REFERENCE_GENOME --V ${SAMPLE}.output.vcf.gz --window 35 --cluster 3 --filter-name "FS" --filter "FS > 30.0" --filter-name "QD" --filter "QD < 2.0" -O ${SAMPLE}.hardfilter.vcf.gz
# keep only calls that pass filters
bcftools view --threads $THREADS -i 'FILTER="PASS"' --output-type z --output-file ${SAMPLE}filtered.vcf.gz ${SAMPLE}.hardfilter.vcf.gz
tabix ${SAMPLE}filtered.vcf.gz # index vcf

### Variant annotation ###
# add gene name
bcftools annotate --threads $THREADS -a $INTERVALS -h $HEADER -c CHROM,FROM,TO,Gene --output-type z --output ${SAMPLE}named.vcf.gz ${SAMPLE}filtered.vcf.gz
tabix ${SAMPLE}named.vcf.gz

# add dbSNP information
bcftools annotate --threads $THREADS -a $DBSNP -c INFO/RS,INFO/COMMON --output-type z --output ${SAMPLE}dbSNP.vcf.gz ${SAMPLE}named.vcf.gz
tabix ${SAMPLE}dbSNP.vcf.gz

# add COSMIC information
bcftools annotate --threads $THREADS -a $COSMIC_VCF -c ID,INFO/CNT --output-type z --output ${SAMPLE}.annotated.vcf.gz ${SAMPLE}dbSNP.vcf.gz
tabix ${SAMPLE}.annotated.vcf.gz

### Output to table ###
bcftools query -H -f '%CHROM\t%POS\t%REF\t%ALT\t%INFO/Gene\t%ID\t%INFO/CNT\t%INFO/RS\t%INFO/COMMON\t[%AD]\n' ${SAMPLE}.annotated.vcf.gz > ${SAMPLE}varTable.tsv

python3 ~/RNA2CM/bin/filter_mutations.py ${SAMPLE} 

if $DELETE_INTERMEDIATES; then
    rm -rf ${SAMPLE}filtered.vcf.gz ${SAMPLE}filtered.vcf.gz.tbi ${SAMPLE}dbSNP.vcf.gz ${SAMPLE}dbSNP.vcf.gz.tbi ${SAMPLE}.hardfilter.vcf.gz ${SAMPLE}.hardfilter.vcf.gz.tbi ${SAMPLE}.annotated.vcf.gz ${SAMPLE}.annotated.vcf.gz.tbi ${SAMPLE}named.vcf.gz ${SAMPLE}named.vcf.gz.tbi
fi

